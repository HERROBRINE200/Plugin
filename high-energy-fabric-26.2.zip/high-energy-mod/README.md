# High Energy — Fabric 26.2
Fabric Minecraft mod project for VS Code.

Commands: /energy, /energy powers, /energy select <power>, /energy guide book english, /energy guide book hindi, /energy guide information english, /energy guide information hindi, and admin energy commands.

Toolchain: Minecraft 26.2, Fabric Loader 0.19.3, Fabric API 0.158.0+26.2, Java 25, Loom 1.18-SNAPSHOT.

Open this folder in VS Code. Build with `gradlew.bat build` after adding the Gradle wrapper or using a compatible Gradle installation.
